﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KursEVM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Translator a = new Translator("<программа>");
            try
            {
                a.Parse(textBox1.Text);
                a.inter.FillGrid(dataGridView1, dataGridView2);
            }
            catch (Exception et)
            {
                MessageBox.Show(et.Message);
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Translator a = new Translator("<программа>");
            try
            {
                a.Parse(textBox1.Text);
                a.inter.Execute();
                a.inter.FillGrid(dataGridView1, dataGridView2);
            }
            catch (Exception et)
            {
                MessageBox.Show(et.Message);
            }
        }
    }
}
