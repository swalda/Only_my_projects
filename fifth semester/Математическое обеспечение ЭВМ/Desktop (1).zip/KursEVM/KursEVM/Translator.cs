﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KursEVM
{
    class Translator
    {
        public class Lexeme : IComparable
        {
            public int Type { get; }
            public string Name { get; set; }
            public int[] attr;

            public virtual bool IsCommand()
            {
                return false;
            }

            public virtual Lexeme Copy()
            {
                return new Lexeme(Type, Name, (attr != null) ? new int[attr.Length] : null);
            }

            public int CompareTo(object obj)
            {
                return Name.CompareTo((string)obj);
            }

            public Lexeme(int type, string name, int[] attr = null)
            {
                Type = type;
                Name = name;
                this.attr = attr;
            }
        }

        public class ComLexeme : Lexeme
        {
            public ComLexeme(int type, string name, int[] attr = null) : base(type, name, attr)
            {

            }
            public override Lexeme Copy()
            {
                return new ComLexeme(Type, Name, (attr != null) ? new int[attr.Length] : null);
            }

            public override bool IsCommand()
            {
                return true;
            }
        }

        public class Lexemer
        {
            public Map<int, Lexeme> types;

            private int Index { get; set; }
            public string Input { get; set; }
            public Lexemer(string LL1)
            {
                types = new Map<int, Lexeme>();
                Index = 0;
                InitLex(LL1);
            }

            public void InitLex(string LL1)
            {
                types.Add(types.Size, new Lexeme(types.Size, "LEXEME_ERROR"));
                types.Add(types.Size, new Lexeme(types.Size, "LEXEME_END_OF_FILE"));
                var m = new Regex(@"\S+").Matches(LL1);
                for (int i = 0; i < m.Count; i++)
                    if ((m[i].Value != "::=") && (m[i].Value != ">>>") &&
                        (types.Get(m[i].Value) == 0) && (m[i].Value != "LEXEME_END_OF_FILE"))
                    {
                        if (m[i].Value.Contains('['))
                        {
                            if (m[i].Value.Contains('{'))
                                types.Add(types.Size,
                                          new ComLexeme(
                                                    types.Size,
                                                    m[i].Value.Substring(0, m[i].Value.IndexOf('[', 0)),
                                                    new int[m[i].Value.Split(new[] { ',' }).Length]
                                          )
                                );
                            else
                                types.Add(types.Size,
                                        new Lexeme(
                                                types.Size,
                                                m[i].Value.Substring(0, m[i].Value.IndexOf('[', 0)),
                                                new int[m[i].Value.Split(new[] { ',' }).Length]
                                       )
                                );
                        }
                        else
                            types.Add(types.Size, new Lexeme(types.Size, m[i].Value));
                    }

            }

            public Lexeme GetLexeme()
            {
                while (Index != Input.Length && Char.IsWhiteSpace(Input[Index]))
                    Index++;
                if (Index == Input.Length)
                    return new Lexeme(types.Get("LEXEME_END_OF_FILE"), "LEXEME_END_OF_FILE");

                if (types.Get(Input.Substring(Index, 1)) != 0 && types.Has(types.Get(Input.Substring(Index, 1))))
                {
                    Index++;
                    return new Lexeme(types.Get(Input.Substring(Index - 1, 1)), Input.Substring(Index - 1, 1));
                }

                if (Index != Input.Length - 1 && types.Get(Input.Substring(Index, 2)) != 0 && types.Has(types.Get(Input.Substring(Index, 2))))
                {
                    Index += 2;
                    return new Lexeme(types.Get(Input.Substring(Index - 2, 2)), Input.Substring(Index - 2, 2));
                }

                if (!Char.IsDigit(Input[Index]))
                {
                    int start = Index;
                    while (Index != Input.Length && (Char.IsLetter(Input[Index]) || Char.IsDigit(Input[Index])))
                        Index++;
                    if (types.Get(Input.Substring(start, Index - start)) != 0 && types.Has(types.Get(Input.Substring(start, Index - start))))
                        return new Lexeme(types.Get(Input.Substring(start, Index - start)), Input.Substring(start, Index - start));
                    else
                        return new Lexeme(types.Get("<ид.>"), Input.Substring(start, Index - start));
                }

                else
                {
                    int start = Index;
                    while (Index != Input.Length && (Char.IsLetter(Input[Index]) || Char.IsDigit(Input[Index])))
                        Index++;
                    if (int.TryParse(Input.Substring(start, Index - start), out int a))
                        return new Lexeme(types.Get("<цел.>"), Input.Substring(start, Index - start));
                    else
                        return new Lexeme(types.Get("LEXEME_ERROR"), Input.Substring(start, Index - start));
                }
            }

            public void Reset()
            {
                Index = 0;
            }
        }

        public class Rule
        {
            public int from;
            public int[] to;
            public int[] choice;
            public int[][] attr;
            public Rule(string s, Lexemer lex)
            { 
                string[] temp;
                var m = new Regex(@"(\S+)\s*::=(.*?)>>>(.*?)\n").Match(s);
                from = lex.types.Get(m.Groups[1].Value.Split(new[] { '[' })[0]);
                var m1 = new Regex(@"\S+").Matches(m.Groups[2].Value);
                to = new int[m1.Count];
                attr = new int[m1.Count + 1][];

                if (m.Groups[1].Value.Contains('['))
                {
                    temp = m.Groups[1].Value.Split(new[] { '[', ']', ',' });

                    attr[0] = new int[temp.Length - 2];
                    for (int j = 1; j < temp.Length - 1; j++)
                        attr[0][j - 1] = Int32.Parse(temp[j]);
                }

                for (int i = 0; i < m1.Count; i++)
                {
                    if (m1[i].Value.Contains('['))
                    {
                        temp = m1[i].Value.Split(new[] { '[', ']', ',' });
                        attr[i + 1] = new int[temp.Length - 2];
                        for (int j = 1; j < temp.Length - 1; j++)
                            attr[i + 1][j - 1] = Int32.Parse(temp[j]);
                    }
                }

                for (int i = 0; i < m1.Count; i++)
                    to[i] = lex.types.Get(m1[i].Value.Split(new[] { '[' })[0]);

                var m2 = new Regex(@"\S+").Matches(m.Groups[3].Value);
                choice = new int[m2.Count];
                for (int i = 0; i < m2.Count; i++)
                    choice[i] = lex.types.Get(m2[i].Value.Split(new[] { '[' })[0]);
            }

            public void ApplyRule(Stack<Lexeme> mag, Map<int, int> addresses, Lexemer lex)
            {
                Map<int, int> temp = new Map<int, int>();
                Lexeme top = mag.Peek();
                if (attr != null)
                {
                    if (attr[0] != null)
                    {
                        for (int i = 0; i < attr[0].Length; i++)
                        {
                            if (!temp.Has(attr[0][i]))
                                temp.Add(attr[0][i], top.attr[i]);
                            else
                                addresses[top.attr[i]] = addresses[temp[attr[0][i]]];
                        }
                    }
                    mag.Pop();

                    for (int i = attr.Length - 1; i >= 1; i--)
                    {
                        Lexeme t = lex.types[to[i - 1]].Copy();
                        for (int j = 0; attr[i] != null && j < attr[i].Length; j++)
                        {
                            if (temp.Has(attr[i][j]))
                                t.attr[j] = temp[attr[i][j]];
                            else
                            {
                                temp.Add(attr[i][j], addresses.Size);
                                addresses.Add(addresses.Size, -1);
                                t.attr[j] = temp[attr[i][j]];
                            }
                        }
                        mag.Push(t);
                    }
                }
                else mag.Pop();
            }

            public Rule(int tfrom)
            {
                from = tfrom;
                choice = new int[1];
                to = new int[0];
                choice[0] = tfrom;
            }
        }

        public class Var : IComparable
        {
            public int Data;
            public string Name { get; set; }
            public bool Set { get; set; }
            public Var(string name)
            {
                Name = name;
                Set = false;
            }
            public Var(string name, int data)
            {
                Data = data;
                Name = name;
                Set = true;
            }
            public int CompareTo(object obj)
            {
                return Name.CompareTo((string)obj);
            }
            public override string ToString()
            {
                return Name;
            }
        }
        Rule[,] table;
        Lexemer lex;
        Stack<Lexeme> mag;
        public Interpretator inter;
        public Translator(string start)
        {
            string LL1 = @"
<программа> ::= <оператор><программа>>>>if for <ид.>[1]
<программа> ::=  >>>
<оператор> ::= <опер.присв.>>>><ид.>[1] 
<оператор> ::= <усл.опер.>>>>if
<оператор> ::= <опер.цикла>>>> for
<опер.присв.> ::= <ид.>[1] = <E>[2] {:=}[1,2] ; >>><ид.>[1]
<усл.опер.> ::= if ( <лог. выраж.>[1] ) then {if}[1,2] <оператор><else>[2] >>>if
<else>[1] ::= else {notif}[2] {lab}[1] <оператор> {lab}[2] >>>else
<else>[1] ::= {lab}[1] >>>if for <ид.>
<опер.цикла> ::= for {lab}[3] ( <ид.>[1] := <F>[2] {:=}[1,2] , <F>[3] {lab}[5] {ifc}[1,3,5] ) while( <лог. выраж.>[1] ) do {if}[1,2] <оператор>  {notif}[3] {lab}[2] >>> for
<E>[1] ::= <T>[2] <E-список>[2,1] >>><ид.>[1] <цел.>[1]
<E-список>[1,2] ::= + <T>[3] {+}[1,3,4] <E-список>[4,2] >>> +
<E-список>[1,1] ::=  >>> ;
<T>[1] ::= <P>[2] <T-список>[2,1] >>><ид.>[1] <цел.>[1]
<T-список>[1,2] ::= * <F>[3] {*}[1,3,4] <T-список>[4,2]  >>> *
<T-список>[1,1] ::=   >>> + ;
<F>[1] ::= <ид.>[1]   >>><ид.>
<F>[1] ::= <цел.>[1]  >>><цел.>
<лог. выраж.>[1] ::= <F>[2] <лог. оп.>[2,1]        >>><ид.>[1] <цел.>[1]
<лог. оп.>[1,2] ::= < <F>[3] {<}[1,3,2]  >>> <
<лог. оп.>[1,2] ::= >= <F>[3] {>=}[1,3,2]  >>> >=
";
            lex = new Lexemer(LL1);
            mag = new Stack<Lexeme>();
            inter = new Interpretator();
            InitRules(LL1);
            mag.Push(lex.types[lex.types.Get("LEXEME_END_OF_FILE")].Copy());
            mag.Push(new Lexeme(lex.types.Get(start), start));
        }
        void InitRules(string LL1)
        {
            table = new Rule[lex.types.Size, lex.types.Size];
            var m = new Regex(@"(\S+)\s*::=(.*?)>>>(.*?)\n").Matches(LL1);
            Rule rule;
            for (int i = 0; i < m.Count; i++)
            {
                rule = new Rule(m[i].Value, lex);
                for (int j = 0; j < rule.choice.Length; j++)
                    table[rule.from, rule.choice[j]] = rule;
            }
            for (int i = 0; i < lex.types.Size; i++)
                table[i, i] = new Rule(i);
        }
        public void PushCommand(Lexeme a)
        {
            switch (a.Name)
            {
                case "{:=}":
                    a.Name = "Присвоить";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{+}":
                    inter.variables.Add(inter.variables.Size, new Var(inter.variables[inter.addresses[a.attr[0]]].Name + "+" + inter.variables[inter.addresses[a.attr[1]]].Name));
                    inter.addresses[a.attr[2]] = inter.variables.Size - 1;
                    a.Name = "Сложить";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{*}":
                    inter.variables.Add(inter.variables.Size, new Var(inter.variables[inter.addresses[a.attr[0]]].Name + "*" + inter.variables[inter.addresses[a.attr[1]]].Name));
                    inter.addresses[a.attr[2]] = inter.variables.Size - 1;
                    a.Name = "Умножить";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{if}":
                    if (inter.addresses[a.attr[1]] == -1)
                    {
                        inter.metki.Add(a.attr[1], inter.metki.Size);
                        inter.addresses[a.attr[1]] = inter.metki.Size - 1;
                    }
                    a.Name = "Условный_переход_по_0";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{notif}":
                    if (inter.addresses[a.attr[0]] == -1)
                    {
                        inter.metki.Add(a.attr[0], inter.metki.Size);
                        inter.addresses[a.attr[0]] = inter.metki.Size - 1;
                    }
                    a.Name = "Безусловный_переход";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{<}":
                    inter.variables.Add(inter.variables.Size, new Var(inter.variables[inter.addresses[a.attr[0]]].Name + "<" + inter.variables[inter.addresses[a.attr[1]]].Name));
                    inter.addresses[a.attr[2]] = inter.variables.Size - 1;
                    a.Name = "Меньше";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{>=}":
                    inter.variables.Add(inter.variables.Size, new Var(inter.variables[inter.addresses[a.attr[0]]].Name + ">=" + inter.variables[inter.addresses[a.attr[1]]].Name));
                    inter.addresses[a.attr[2]] = inter.variables.Size - 1;
                    a.Name = "Больше_равно";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
                case "{lab}":
                    if (inter.addresses[a.attr[0]] == -1)
                    {
                        inter.metki.Add(a.attr[0], inter.metki.Size);
                        inter.addresses[a.attr[0]] = inter.metki.Size - 1;
                    }
                    a.Name = "Метка";
                    inter.AddCommand((ComLexeme)a);
                    mag.Pop();
                    break;
            }
        }
        public bool ParseStep(Lexeme a)
        {
            int type = a.Type;
            int stacktype = mag.Peek().Type;
            do
            {
                if (mag.Peek().IsCommand())
                {
                    PushCommand(mag.Peek());
                    continue;
                }
                if (mag.Peek().Name == "<ид.>" && a.Type == lex.types.Get("<ид.>"))
                {
                    if ((inter.variables.Size == 0 || inter.variables.Get(a.Name) == 0))
                    {
                        inter.variables.Add(inter.variables.Size, new Var(a.Name));
                        inter.addresses[mag.Peek().attr[0]] = inter.variables.Size - 1;
                    }
                    else
                    {
                        inter.addresses[mag.Peek().attr[0]] = inter.variables.Get(a.Name);
                    }
                }
                if (mag.Peek().Name == "<цел.>" && a.Type == lex.types.Get("<цел.>"))
                {
                    if ((inter.variables.Size == 0 || inter.variables.Get(a.Name) == 0))
                    {
                        inter.variables.Add(inter.variables.Size, new Var(a.Name, Int32.Parse(a.Name)));
                        inter.addresses[mag.Peek().attr[0]] = inter.variables.Size - 1;
                    }
                    else
                    {
                        inter.addresses[mag.Peek().attr[0]] = inter.variables.Get(a.Name);
                    }
                }
                stacktype = mag.Peek().Type;
                Rule rule = table[stacktype, type];
                if (rule == null)
                    throw new Exception(String.Format("Expected '{0}' but got '{1}'", lex.types[stacktype].Name, a.Name));
                else
                {
                    rule.ApplyRule(mag, inter.addresses, lex);
                }
            } while (stacktype != type);
            return true;
        }
        public void Parse(string input)
        {
            lex.Input = input;
            Lexeme a = null;
            do
            {
                a = lex.GetLexeme();
                ParseStep(a);
            } while (a.Type != lex.types.Get("LEXEME_END_OF_FILE"));
        }
        public class Interpretator
        {
            public ComLexeme[] mag;
            public Map<int, Var> variables;
            public Map<int, int> addresses;
            public Map<int, int> metki;
            public int size;
            public Interpretator()
            {
                variables = new Map<int, Var>();
                addresses = new Map<int, int>();
                metki = new Map<int, int>();
                mag = new ComLexeme[100];
                size = 0;
            }
            public void AddCommand(ComLexeme a)
            {
                mag[size] = a;
                size++;
            }
            public void FillGrid(DataGridView oper, DataGridView data)
            {
                oper.Rows.Clear();
                data.Rows.Clear();
                for (int i = 0; i < size; i++)
                {
                    string attr = "(";
                    for (int j = 0; j < mag[i].attr.Length; j++)
                        if (j == mag[i].attr.Length - 1)
                            attr += addresses[mag[i].attr[j]];
                        else
                            attr += addresses[mag[i].attr[j]].ToString() + ",";
                    attr += ")";
                    oper.Rows.Add(mag[i].Name + attr);
                }
                for (int i = 1; i < variables.Size; i++)
                {
                    data.Rows.Add(i, variables[i].Name, variables[i].Data);
                }
            }
            public void Execute()
            {
                int index = 0;
                while (index < size)
                {
                    ComLexeme com = mag[index];
                    switch (com.Name)
                    {
                        case "Присвоить":
                            if (!variables[addresses[com.attr[1]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[1]]].Name));
                            variables[addresses[com.attr[0]]].Data = variables[addresses[com.attr[1]]].Data;
                            variables[addresses[com.attr[0]]].Set = true;
                            index++;
                            break;
                        case "Сложить":
                            if (!variables[addresses[com.attr[0]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[0]]].Name));
                            if (!variables[addresses[com.attr[1]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[1]]].Name));
                            variables[addresses[com.attr[2]]].Data = variables[addresses[com.attr[0]]].Data + variables[addresses[com.attr[1]]].Data;
                            variables[addresses[com.attr[2]]].Set = true;
                            index++;
                            break;
                        case "Умножить":
                            if (!variables[addresses[com.attr[0]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[0]]].Name));
                            if (!variables[addresses[com.attr[1]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[1]]].Name));
                            variables[addresses[com.attr[2]]].Data = variables[addresses[com.attr[0]]].Data * variables[addresses[com.attr[1]]].Data;
                            variables[addresses[com.attr[2]]].Set = true;
                            index++;
                            break;
                        case "Условный_переход_по_0":
                            if (variables[addresses[com.attr[0]]].Data == 0)
                            {
                                for (int i = 0; i < size; i++)
                                    if (mag[i].Name == "Метка" && com.attr[1] == mag[i].attr[0])
                                        index = i;
                            }
                            else
                                index++;
                            break;
                        case "Безусловный_переход":
                            for (int i = 0; i < size; i++)
                                if (mag[i].Name == "Метка" && com.attr[0] == mag[i].attr[0])
                                    index = i;
                            break;
                        case "Меньше":
                            if (!variables[addresses[com.attr[0]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[0]]].Name));
                            if (!variables[addresses[com.attr[1]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[1]]].Name));
                            if (variables[addresses[com.attr[0]]].Data < variables[addresses[com.attr[1]]].Data)
                                variables[addresses[com.attr[2]]].Data = 1;
                            else
                                variables[addresses[com.attr[2]]].Data = 0;
                            variables[addresses[com.attr[2]]].Set = true;
                            index++;
                            break;
                        case "Больше_равно":
                            if (!variables[addresses[com.attr[0]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[0]]].Name));
                            if (!variables[addresses[com.attr[1]]].Set)
                                throw new Exception(String.Format("{0} is not set", variables[addresses[com.attr[1]]].Name));
                            if (variables[addresses[com.attr[0]]].Data >= variables[addresses[com.attr[1]]].Data)
                                variables[addresses[com.attr[2]]].Data = 1;
                            else
                                variables[addresses[com.attr[2]]].Data = 0;
                            variables[addresses[com.attr[2]]].Set = true;
                            index++;
                            break;
                        case "Метка":
                            index++;
                            break;
                    }
                }
            }
        }

    }
}
