﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace EVMlab3
{
    public partial class Form1 : Form
    {
        Analiz Avtomat = new Analiz();
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Avtomat.str = textBox1.Text;
            int lex;
            Avtomat.kar = 0;
            Avtomat.Automat.push(0);
            Avtomat.Automat.push(20);
            int temp = Avtomat.Automat.top();
            bool flag;
            lex = Avtomat.ScanStr(Avtomat.str, ref Avtomat.kar);
            flag = Avtomat.mpauto(temp, lex);
            if (!flag)
            {
                MessageBox.Show("Ошибка во введенной программе");
                while (!Avtomat.Automat.isempty())
                    Avtomat.Automat.pop();
            }
            else if (flag)
                MessageBox.Show("Анализ завершен успешно");
        }
    }
    class node
    {
        public string name;
        public int atribute;
        public node next;
        public node()
        {
            next = null;
            name = "";
            atribute = -1;
        }
    }

    class nod
    {
        public int a;
        public nod next;
        public nod()
        {
            nod next = null;
            int a = -1;
        }
    }

    class stek
    {
        public nod head;
        public stek()
        { nod head = null; }
        public void push(int x)
        {
            nod p = new nod();
            p.a = x;
            p.next = head;
            head = p;
        }
        public bool isempty()
        {
            if (head == null) return true;
            else return false;
        }
        public void pop()
        {
            int x = head.a;
            nod p = head;
            head = head.next;
        }
        public int top()
        {
            int x = head.a;
            return x;
        }
    }


    class table
    {
        node head;
        //свойство для доступа к голове списка
        public node Dostup
        {
            set
            { head = value; }
            get
            { return head; }
        }
        public table()
        { head = null; }
        public void add(string name1, int atr)
        {
            node check = search(name1);
            if (check == null)
            {
                node temp = new node();
                temp.name = name1;
                temp.atribute = atr;
                temp.next = head;
                head = temp;
            }
            else Console.WriteLine("Такой элемент уже есть");
            return;
        }
        public void print()
        {
            node VarToMove = head;
            while (VarToMove != null)
            {
                Console.WriteLine("Имя арибута" + VarToMove.name + " атрибут" + VarToMove.atribute);
                VarToMove = VarToMove.next;
            }
            return;
        }
        public node search(string name2)
        {
            node Check = null;
            node VarToMove = head;
            while (VarToMove != null)
            {
                if (VarToMove.name == name2)
                {
                    Check = new node();
                    Check.name = VarToMove.name;
                    Check.atribute = VarToMove.atribute;
                    return Check;
                }
                VarToMove = VarToMove.next;
            }
            return Check;
        }

        public int search2(string name2)
        {
            int Check = 0;
            node VarToMove = head;
            while (VarToMove != null)
            {
                if (VarToMove.name == name2)
                {
                    Check = VarToMove.atribute;
                    break;
                }
                else
                    VarToMove = VarToMove.next;
            }
            if (VarToMove == null)
                return 0;
            else
                return Check;
        }
        public void delete(string name3)
        {
            node VarToMove = head;
            node save = head;
            while (VarToMove != null)
            {
                if (VarToMove.name == name3)
                {
                    save = VarToMove.next;
                    return;
                }
                save = VarToMove;
                VarToMove = VarToMove.next;
            }
        }
    }

    class Analiz
    {
        public int kar; 
        public string str;
        public static int prisv = 1; // присваивание
        public static int plus = 2; // сложение 
        public static int tz = 3; // точка с запятой 
        public static int umn = 4; // умножение
        public static int lsk = 5; // левая скобка
        public static int psk = 6; // правая скобка
        public static int nr = 7; // меньше
        public static int rr = 8; // больше_меньше
        public static int buk = 9; // буква
        public static int cif = 10; // цифра
        public static int niz = 16;//нижнее подчеркивание
        public static int iff = 11;// if
        public static int zap = 18;// запятая
        public static int thenn = 17;// then
        public static int elss = 12; // else
        public static int forr = 13; // for
        public static int whill = 14;// while
        public static int doo = 15;// do
        public static int prog = 20;// <программа>
        public static int oper = 21;//<оператор>
        public static int soper = 22;//<список операторов>
        public static int e = 23;//<E>
        public static int t = 24;//<T>
        public static int es = 25;//<Eсписок>
        public static int ts = 26;//<Tсписок>
        public static int f = 27;//<F>
        public static int logv = 30;//<лог выр>
        public static int logo = 31;//<лог опер>
        public static int sd = 0;//маркер дна
        public table razdel; //таблица для разделительных знаков
        public table kluch; //таблица для ключевых слов
        public table ident;// таблица идентификаторов
        public stek Automat;

        public Analiz()
        {
            razdel = new table();
            kluch = new table();
            ident = new table();
            str = null;
            Automat = new stek();
            //заполнение таблички ключевых слов
            kluch.add("if", iff);
            kluch.add("then", thenn);
            kluch.add("else", elss);
            kluch.add("for", forr);
            kluch.add("while", whill);
            kluch.add("do", doo);
            //заполнение таблички разделителей
            razdel.add(":=", prisv);
            razdel.add("+", plus);
            razdel.add(";", tz);
            razdel.add("*", umn);
            razdel.add("(", lsk);
            razdel.add(")", psk);
            razdel.add("<", nr);
            razdel.add(">=", rr);
            razdel.add(",", zap);
        }
        public bool prinadl(char x) //проверка на принадлежность грамматике
        {
            if (x >= 'a' && x <= 'z')
                return true;
            else if (x >= '0' && x <= '9')
                return true;
            else if (x == ':')
                return true;
            else if (x == ' ')
                return true;
            else if (x == '=')
                return true;
            else if (x == '+')
                return true;
            else if (x == ';')
                return true;
            else if (x == ',')
                return true;
            else if (x == '_')
                return true;
            else if (x == ',')
                return true;
            else if (x == '*')
                return true;
            else if (x == '(')
                return true;
            else if (x == ')')
                return true;
            else if (x == '<')
                return true;
            else if (x == '>')
                return true;
            else if (x == '\r' || x == '\n')
                return true;
            return false;
        }
        public bool provraz(char x)//проверка на разделители
        {
            if (x == ':')
                return true;
            else if (x == '=')
                return true;
            else if (x == '+')
                return true;
            else if (x == ';')
                return true;
            else if (x == ',')
                return true;
            else if (x == '*')
                return true;
            else if (x == '(')
                return true;
            else if (x == ')')
                return true;
            else if (x == '<')
                return true;
            else if (x == '>')
                return true;
            return false;
        }
        public bool mpauto(int mg, int vh)
        {
            int temp;
            int v;
            bool flag = true;
            switch (mg)
            {
                case 20:
                    switch (vh)
                    {
                        case 9:
                        case 11:
                        case 13:
                            Automat.pop();
                            Automat.push(oper);
                            Automat.push(doo);
                            Automat.push(whill);
                            Automat.push(psk);
                            Automat.push(f);
                            Automat.push(zap);
                            Automat.push(f);
                            Automat.push(prisv);
                            Automat.push(buk);
                            Automat.push(lsk);
                            flag = mpauto(oper, vh);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 22:
                    switch (vh)
                    {
                        case 9:
                        case 11:
                        case 13:
                            Automat.pop();
                            Automat.push(oper);
                            Automat.push(doo);
                            Automat.push(whill);
                            Automat.push(psk);
                            Automat.push(f);
                            Automat.push(zap);
                            Automat.push(f);
                            Automat.push(prisv);
                            Automat.push(buk);
                            Automat.push(lsk);
                            flag = mpauto(oper, vh);
                            break;
                        case 14:
                        case 0:
                            Automat.pop();
                            temp = Automat.top();
                            flag = mpauto(temp, vh);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 21:
                    switch (vh)
                    {
                        case 9:
                            Automat.pop();
                            Automat.push(tz);
                            Automat.push(e);
                            Automat.push(prisv);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(prisv, v);
                            break;
                        case 11:
                            Automat.pop();
                            Automat.push(elss);
                            Automat.push(oper);
                            Automat.push(thenn);
                            Automat.push(psk);
                            Automat.push(logv);
                            Automat.push(lsk);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(lsk, v);
                            break;
                        case 13:
                            Automat.pop();
                            Automat.push(oper);
                            Automat.push(doo);
                            Automat.push(whill);
                            Automat.push(psk);
                            Automat.push(f);
                            Automat.push(zap);
                            Automat.push(f);
                            Automat.push(prisv);
                            Automat.push(buk);
                            Automat.push(lsk);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(soper, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 23:
                    switch (vh)
                    {
                        case 9:
                        case 10:
                            Automat.pop();
                            Automat.push(es);
                            Automat.push(t);
                            flag = mpauto(t, vh);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 24:
                    switch (vh)
                    {
                        case 9:
                        case 10:
                            Automat.pop();
                            Automat.push(ts);
                            Automat.push(f);
                            flag = mpauto(f, vh);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 25:
                    switch (vh)
                    {
                        case 2:
                            Automat.pop();
                            Automat.push(es);
                            Automat.push(t);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(t, v);
                            break;
                        case 3:
                            Automat.pop();
                            temp = Automat.top();
                            flag = mpauto(temp, vh);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 26:
                    switch (vh)
                    {
                        case 2:
                        case 3:
                            Automat.pop();
                            temp = Automat.top();
                            flag = mpauto(temp, vh);
                            break;
                        case 4:
                            Automat.pop();
                            Automat.push(ts);
                            Automat.push(f);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(f, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 27:
                    switch (vh)
                    {
                        case 9:
                        case 10:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 9:
                    switch (vh)
                    {
                        case 9:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 1:
                    switch (vh)
                    {
                        case 1:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 30:
                    switch (vh)
                    {
                        case 9:
                        case 10:
                            Automat.pop();
                            Automat.push(f);
                            Automat.push(logo);
                            Automat.push(f);
                            flag = mpauto(f, vh);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 31:
                    switch (vh)
                    {
                        case 7:
                        case 8:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 12:
                    switch (vh)
                    {
                        case 12:
                            Automat.pop();
                            Automat.push(oper);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(oper, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 14:
                    switch (vh)
                    {
                        case 14:
                            Automat.pop();
                            Automat.push(psk);
                            Automat.push(logv);
                            Automat.push(lsk);
                            v = ScanStr(str, ref kar);
                            flag = mpauto(oper, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 5:
                    switch (vh)
                    {
                        case 5:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 6:
                    switch (vh)
                    {
                        case 6:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 3:
                    switch (vh)
                    {
                        case 3:
                            Automat.pop();
                            temp = Automat.top();
                            v = ScanStr(str, ref kar);
                            flag = mpauto(temp, v);
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
                case 0:
                    switch (vh)
                    {
                        case 0:
                            flag = true;
                            break;
                        default:
                            flag = false;
                            break;
                    }
                    break;
            }
            return flag;
        }
        public int ScanStr(string str, ref int kar)//сканирование строки
        {
            char cur = ' ';
            string num = null;
            string word = null;
            string sep = null;
            if (kar < str.Length)
                cur = str[kar];
            else if (kar > str.Length)
                return -1;
            else if (kar == str.Length)
                return 0;
            //пропуск пробелов и тд
            while ((cur == ' ' || cur == '\t' || cur == '\r' || cur == '\n') && kar < str.Length)
            {
                kar++;
                if (kar < str.Length)
                    cur = str[kar];
                if (kar == str.Length)
                    return 0;
            }
            //проверка на число
            if (cur >= '0' && cur <= '9')
            {
                do
                {
                    num += cur;
                    kar++;
                    if (kar >= str.Length)
                        break;
                    cur = str[kar];
                }
                while (cur >= '0' && cur <= '9');
                if (cur >= 'a' && cur <= 'z')
                    return -1;
                if (ident.search(num) == null)
                { ident.add(num, cif); }
                return ident.search2(num);
            }
            //проверка на буквы
            if ((cur >= 'a' && cur <= 'z') || (cur == '_'))
            {
                do
                {
                    word += cur;
                    kar++;
                    if (kar < str.Length)
                        cur = str[kar];
                    else
                        break;
                }
                while (cur >= 'a' && cur <= 'z' || cur == '_');
                if (!prinadl(cur))
                    return -1;
                if (kluch.search(word) != null)
                    return kluch.search2(word);
                else if (ident.search(word) == null)
                { ident.add(word, buk); }
                return ident.search2(word);
            }
            //проверка на разделитель
            if (provraz(cur))
            {
                do
                {
                    sep += cur;
                    kar++;
                    if (kar < str.Length)
                        cur = str[kar];
                    else
                        break;
                }
                while (provraz(cur));
                if (!prinadl(cur))
                    return -1;
                return razdel.search2(sep);
            }
            else return -1;
        }
    }
}
