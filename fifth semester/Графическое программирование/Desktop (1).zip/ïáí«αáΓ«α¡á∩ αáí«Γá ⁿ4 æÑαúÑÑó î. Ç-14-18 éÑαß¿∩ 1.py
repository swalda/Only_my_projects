#!/usr/bin/env python
# coding: utf-8

# In[26]:


import pyglet
from pyglet import app, gl, graphics
from pyglet.window import Window, key
h = 20 # Половины длины ребра куба
w = 2 * h # Для задания области вывода
width = height = 300 # Размер окна вывода
textureIDs = (gl.GLuint * 7)() # Массив идентификаторов (номеров) текстур
p = gl.GL_TEXTURE_2D
tx = 2
ty = 1
rot_x = 60# Углы поворота вокруг осей X, Y и Z
rot_y = 0 # (15, 25, 15) или (-25, 215, -15)
rot_z = 0
verts = ((h/(1.8), -h/2, -h), #0
         (h, h, -h), #1
         (-h, h, -h),#2
         (-h/(1.8), -h/2, -h),#3
         (h/(1.8), -h/2, h),#4
         (h, h, h),#5
         (-h/(1.8), -h/2, h),#6
         (-h, h, h),#7
         (0, -h, -h),#8
         (0, -h, h))#9
faces = ((8, 0, 1, 2, 3),
         (1, 5, 7, 2),
         (8, 9, 4, 0),
         (0, 4, 5, 1),
         (2, 7, 6, 3),
         (3, 6, 9, 8),
         (9, 6, 7, 5, 4))
clrs = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0),
        (0, 1, 1), (1, 1, 1), (1, 0, 0), (0, 1, 0),
        (0, 0, 1), (1, 1, 0), (0, 1, 1), (1, 1, 1),
        (0, 1, 0), (1, 0, 0), (1, 1, 0))
# Индексы ребер куба (используется при выводе линий вдоль ребер куба)
edges = ((0, 1), (0, 4), (0, 8), (1, 2), (1, 5), (2, 3),
         (2, 7), (3, 6), (3, 8), (4, 5), (4, 9), (5, 7),
         (6, 7),(6, 9), (8, 9))
def texInit(): # Формирование текстур
    gl.glGenTextures(7, textureIDs)
    r = gl.GL_RGB
    p3 = gl.GL_REPEAT # GL_REPEAT GL_CLAMP_TO_EDGE
    p4 = gl.GL_LINEAR
    for k in range(7):
        fn = 'C:\\Users\\Максим\\Pictures\\1356816110_umilnye-zhivotnye-24.jpg'
        img = pyglet.image.load(fn)
        iWidth = img.width
        iHeight = img.height
        img = img.get_data('RGB', iWidth * 3)
        gl.glBindTexture(p, textureIDs[k])
        gl.glTexParameterf(p, gl.GL_TEXTURE_WRAP_S, p3)
        gl.glTexParameterf(p, gl.GL_TEXTURE_WRAP_T, p3)
        gl.glTexParameterf(p, gl.GL_TEXTURE_MAG_FILTER, p4)
        gl.glTexParameterf(p, gl.GL_TEXTURE_MIN_FILTER, p4)
        gl.glTexEnvf(gl.GL_TEXTURE_ENV, gl.GL_TEXTURE_ENV_MODE, gl.GL_DECAL)
        gl.glTexImage2D(p, 0, r, iWidth, iHeight, 0, r, gl.GL_UNSIGNED_BYTE, img)
    gl.glEnable(p)
def cube_draw():
    k = -1
    t_coords = ((tx, ty), (tx, 0), (0, 0), (0, ty))
    t_coords1 = ((0, 0), (0, ty), (tx, ty),(tx, 0),(tx, ty))
    for face in faces:
        k += 1
        m = -1
        v4, c4, t4, t4a= (), (), (), ()
        gl.glBindTexture(p, textureIDs[k])
        for v in face:
            m += 1
            c4 += clrs[k + m]
            if m<4:
                t4 += t_coords[m]
            if m<5:
                t4a += t_coords1[m]
            v4 += verts[v]
        if m == 4:
            graphics.draw(5, gl.GL_POLYGON, ('v3f', v4), ('c3f', c4), ('t2f', t4a))
        if m == 3:
            graphics.draw(4, gl.GL_POLYGON, ('v3f', v4), ('c3f', c4), ('t2f', t4))
window = Window(visible = True, width = width, height = height,
                resizable = True, caption = 'Куб')
gl.glClearColor(0, 0, 0, 1) # Черный цвет фона
gl.glClear(gl.GL_COLOR_BUFFER_BIT|gl.GL_DEPTH_BUFFER_BIT)
gl.glPolygonMode(gl.GL_FRONT, gl.GL_FILL)
gl.glEnable(gl.GL_CULL_FACE)
gl.glEnable(gl.GL_DEPTH_TEST)
#
texInit() # Создаем текстуры
#
@window.event
def on_draw():
    window.clear()
    gl.glMatrixMode(gl.GL_PROJECTION)
    gl.glLoadIdentity()
    gl.glOrtho(-w, w, -w, w, -w, w)
    gl.glRotatef(rot_x, 1, 0, 0) # Поворот относительно оси X
    gl.glRotatef(rot_y, 0, 1, 0) # Поворот относительно оси Y
    gl.glRotatef(rot_z, 0, 0, 1) # Поворот относительно оси Z
    cube_draw()
@window.event
def on_key_press(symbol, modifiers):
    global tx, ty, rot_x, rot_y
    if symbol == key._1:
        tx = ty = 1
    elif symbol == key._2:
        tx = ty = 2
    elif symbol == key._3:
        tx = 3
        ty = 2
    elif symbol == key._4:
        rot_x +=5
    elif symbol == key._5:
        rot_y +=5   
app.run()


# In[ ]:





# In[ ]:




