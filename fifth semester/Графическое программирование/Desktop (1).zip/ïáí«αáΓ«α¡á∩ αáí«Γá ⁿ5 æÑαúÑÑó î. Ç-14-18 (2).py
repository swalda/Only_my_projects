#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pyglet
from pyglet import app, gl, graphics
from pyglet.window import Window, key
import numpy as np
import random
save_to_file = True
d = 12
wx, wy = 2 * d , 2 * d 
vrts = []
vrts_top = []
vrts_down = []
rot_x = 45
rot_y = 0 
rot_z = 0
ca = 1
cb = 0
cc = 0
fl = False

width, height = int(20 * wx), int(20 * wy) 
window = Window(visible = True, width = width, height = height,
                resizable = True, caption = 'Половина однополосного гиперболоида')
gl.glClearColor(0.1, 0.1, 0.1, 1.0)
gl.glClear(gl.GL_COLOR_BUFFER_BIT|gl.GL_DEPTH_BUFFER_BIT)
gl.glPolygonMode(gl.GL_FRONT, gl.GL_FILL)
gl.glEnable(gl.GL_CULL_FACE)
gl.glEnable(gl.GL_DEPTH_TEST)
gl.glPointSize(3)   
def parobaloyd_draw():
    global fl, ca, cb, cc, vrts, vrts_top, vrts_down
    #Нижняя крышка
    t = 0
    gl.glBegin(gl.GL_POLYGON)
    while (t<2*np.pi):
        k = 0
        x = 8*np.cosh(k)*np.cos(t)
        y = 8*np.cosh(k)*np.sin(t)
        z = 10*np.sinh(k)
        if (fl == True):
            ca = random.random()
            cb = random.random()
            cc = random.random()
            gl.glColor3f(ca,cb,cc)
        else:
            gl.glColor3f(ca,cb,cc)
        gl.glVertex3f(x,y,z) 
        vrts_down.append([x,y,z])
        t+=0.1
    gl.glEnd()
    
    #Верхняя крышка
    t = 0
    gl.glBegin(gl.GL_POLYGON)
    while (t>-2*np.pi):
        k = -1
        x = 8*np.cosh(k)*np.cos(t)
        y = 8*np.cosh(k)*np.sin(t)
        z = 10*np.sinh(k)
        if (fl == True):
            ca = random.random()
            cb = random.random()
            cc = random.random()
            gl.glColor3f(ca,cb,cc)
        else:
            gl.glColor3f(ca,cb,cc)
        gl.glVertex3f(x,y,z) 
        vrts_top.append([x,y,z])
        t-=0.1
    gl.glEnd() 
     
    #Боковая сторона параболоида
    t = 0
    while (t<=2*np.pi):
        k = -1
        while (k<=0):
            a = k + 0.1
            gl.glBegin(gl.GL_QUADS)
            while (k<=a):
                x = 8*np.cosh(k)*np.cos(t)
                y = 8*np.cosh(k)*np.sin(t)
                z = 10*np.sinh(k)
                if (fl == True):
                    ca = random.random()
                    cb = random.random()
                    cc = random.random()
                    gl.glColor3f(ca,cb,cc)
                else:
                    gl.glColor3f(ca,cb,cc)
                gl.glVertex3f(x,y,z)
                vrts.append([x,y,z])
                k+=0.1
            k-=0.1
            t-=0.1
            a = k - 0.1
            while (k>=a):
                x = 8*np.cosh(k)*np.cos(t)
                y = 8*np.cosh(k)*np.sin(t)
                z = 10*np.sinh(k)
                gl.glVertex3f(x,y,z)
                k-=0.1
            k+=0.2
            t+=0.1
            gl.glEnd()
        t+=0.1

def save_file():
    global vrts, vrts_top, vrts_down
    print("Запись данных в двоичные файлы")
    def write_to_bin(file,data):
        fn = open(file, 'wb')
        fn.write(np.array(data))
        fn.close()
    write_to_bin('vrts.bin', vrts)
    write_to_bin('vrts_top.bin', vrts_top)
    write_to_bin('vrts_down.bin', vrts_down)
    
@window.event
def on_draw():
    window.clear()
    gl.glMatrixMode(gl.GL_PROJECTION)
    gl.glLoadIdentity()
    gl.glOrtho(-wx, wx, -wy, wy, -20, 20)
    gl.glRotatef(rot_x, 1, 0, 0) 
    gl.glRotatef(rot_y, 0, 1, 0) 
    gl.glRotatef(rot_z, 0, 0, 1)
    parobaloyd_draw()
    if save_to_file:
        save_file()      
@window.event
def on_key_press(symbol, modifiers):
    global rot_x, rot_y, rot_z, ca, cb, cc, fl
    if symbol == key._1:
        gl.glPolygonMode(gl.GL_FRONT, gl.GL_LINE)
    elif symbol == key._2:
        gl.glPolygonMode(gl.GL_FRONT, gl.GL_POINT)
    elif symbol == key._3:
        fl = True
        gl.glShadeModel(gl.GL_FLAT)
    elif symbol == key._4:
        fl = True
        gl.glShadeModel(gl.GL_SMOOTH)
    elif symbol == key._5:
        fl = False
        rot_x +=5  
    elif symbol == key._6:
        fl = False
        rot_y +=5  
    elif symbol == key._7:
        fl = False
        rot_z +=5  
    elif symbol == key._8:
        gl.glPolygonMode(gl.GL_FRONT, gl.GL_FILL)  
        fl = False
        ca = 1
        cb = 0
        cc = 0
app.run()


# In[ ]:





# In[ ]:




