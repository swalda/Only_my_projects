#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pyglet
from pyglet import app, gl, graphics
from pyglet.window import Window, key
import numpy as np
import random
from sys import exit
save_to_file = False
read_from_file = False
if read_from_file: save_to_file = False
plot_surf = False
show_normals = True
use_txtr = True
texFromFile = False
if use_txtr: show_normals = False
d = 12
wx, wy = 2 * d , 2 * d 
vrts = []
vrts_top = []
vrts_down = []
nrms = []
nrms_top = []
nrms_down = []
textr = []
textr_top = []
textr_down = []
rot_x = 45
rot_y = 0 
rot_z = 0
ca = 1
cb = 0
cc = 0
cof = 0.2
n = 0
fl = False

if read_from_file==True:
    print('Загрузка данных из двоичных файлов')
    def load_data(file, shape = None):
        with open(file, 'rb') as r_b:
            data = np.fromfile(r_b)
        if shape is not None:
            size = len(data)
            if len(shape) == 2:
                size = int(size / (shape[0] * shape[1]))
                data = data.reshape(size, shape[0], shape[1])
            else:
                size = int(size / shape[0])
                data = data.reshape(size, shape[0])
        return data
    vrts = load_data('vrts.bin', [4, 3])
    vrts_top = load_data('vrts_top.bin', [3])
    nrms = load_data('nrms.bin', [3])
    nrm_top = load_data('nrm_top.bin', None)
    nrm_down = load_data('nrm_down.bin', None)
    textr = load_data('textr.bin', [2])
    textr_top = load_data('textr_top.bin', [2])
    textr_down = load_data('textr_down.bin', [2])
else:
    #Нижняя крышка
    t = 0
    n = 0
    while (t<2*np.pi):
        n+= 1
        k = 0
        x = 8*np.cosh(k)*np.cos(t)
        y = 8*np.cosh(k)*np.sin(t)
        z = 10*np.sinh(k) 
        vrts_down.append([x,y,z])
        textr.append([abs(t*10)*0.1,1])
        if texFromFile:
            j2 = 2 * (abs(t*10)) * 0.1
            if abs(t*10) <=  10 / 4:
                textr_down.append([j2, 0.5 - j2])
            elif abs(t*10) <= 10 / 2:
                textr_down.append([j2, j2 - 0.5])
            elif abs(t*10)<= 3 * 10 / 4:
                textr_down.append([2 - j2, j2 - 0.5])
            else:
                textr_down.append([2 - j2, 2.5 - j2])
        else:
            textr_down.append([0.25*x,0.25*y])
        t+=0.1
    v0 = np.array(vrts_down[0])
    v1 = np.array(vrts_down[1])
    vn = np.array(vrts_down[n-1])
    nrm_down = np.cross(v1 - v0, vn - v0) # Нормаль к крышке
    nrm_down = nrm_down / np.linalg.norm(nrm_down)
    
    #Верхняя крышка
    t = 0
    n = 0
    while (t>-2*np.pi):
        n+= 1
        k = -1
        x = 8*np.cosh(k)*np.cos(t)
        y = 8*np.cosh(k)*np.sin(t)
        z = 10*np.sinh(k)
        vrts_top.append([x,y,z])
        textr.append([abs(t*10)*0.1,1])
        if texFromFile:
            j2 = 2 * (abs(t*10)) * 0.1
            if abs(t*10) <=  10 / 4:
                textr_top.append([j2, 0.5 - j2])
            elif abs(t*10) <= 10 / 2:
                textr_top.append([j2, j2 - 0.5])
            elif abs(t*10) <= 3 * 10 / 4:
                textr_top.append([2 - j2, j2 - 0.5])
            else:
                textr_top.append([2 - j2, 2.5 - j2])
        else:
            textr_top.append([0.25*x,0.25*y])
        t-=0.1
    v0 = np.array(vrts_top[0])
    v1 = np.array(vrts_top[1])
    vn = np.array(vrts_top[n-1])
    nrm_top = np.cross(v1 - v0, vn - v0) # Нормаль к крышке
    nrm_top = nrm_top / np.linalg.norm(nrm_top)
     
    #Боковая сторона параболоида
    t = 0
    p = 0
    while (t<=2*np.pi):
        k = -1
        while (k<=0):
            x = 8*np.cosh(k)*np.cos(t)
            y = 8*np.cosh(k)*np.sin(t)
            z = 10*np.sinh(k)
            v0 = np.array([x,y,z])
            x = 8*np.cosh(k+0.1)*np.cos(t)
            y = 8*np.cosh(k+0.1)*np.sin(t)
            z = 10*np.sinh(k+0.1)
            v1 = np.array([x,y,z])
            k+=0.1
            x = 8*np.cosh(k)*np.cos(t-0.1)
            y = 8*np.cosh(k)*np.sin(t-0.1)
            z = 10*np.sinh(k)
            v2 = np.array([x,y,z])
            x = 8*np.cosh(k-0.1)*np.cos(t-0.1)
            y = 8*np.cosh(k-0.1)*np.sin(t-0.1)
            z = 10*np.sinh(k-0.1)
            v3 = np.array([x,y,z])
            vrts.append([v0,v1,v2,v3])
            a = v1 - v0
            b = v3 - v0
            sab = np.cross(a, b)
            sab = sab / np.linalg.norm(sab)
            nrms.append(sab)
            p+=0.1
            textr.append([0.1*abs(k-0.1),(p-0.1)/12])
        t+=0.1
print(10*np.sinh(-1)-10*np.sinh(0))
if save_to_file==True:
    print("Запись данных в двоичные файлы")
    def write_to_bin(file,data):
        fn = open(file, 'wb')
        fn.write(np.array(data))
        fn.close()
    write_to_bin('vrts.bin', vrts)
    write_to_bin('vrts_top.bin', vrts_top)
    write_to_bin('vrts_down.bin', vrts_down)

if plot_surf:
    from mpl_toolkits.mplot3d import Axes3D # Для projection = '3d'
    from matplotlib import cm
    import matplotlib.pyplot as plt
    xy, z = [], []
    x_min = x_max = vrts[0][0][0]
    y_min = y_max = vrts[0][0][1]
    for quad in vrts:
        for v in quad:
            p = [v[0], v[1]]
            if not p in xy:
                xy.append(p)
                z.append(v[2])
                if p[0] < x_min: x_min = p[0]
                if p[0] > x_max: x_max = p[0]
                if p[1] < y_min: y_min = p[1]
                if p[1] > y_max: y_max = p[1]
    step = 0.5
    X = np.arange(x_min, x_max, step) # Формирование сетки
    Y = np.arange(y_min, y_max, step)
    X, Y = np.meshgrid(X, Y)
    Z = np.sqrt(((cof**2)*X**2+(cof**2)*Y**2-1)*(cof**2)) # Формируем массив Z формы (len(X), len(Y))
    fig = plt.figure()
    ax = fig.gca(projection = '3d')
    surf = ax.plot_surface(X, Y, Z, cmap = cm.plasma) # plasma Spectral
    ax.set_xlabel('X') # Метки осей координат
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    for label in ax.xaxis.get_ticklabels(): # Настройка оси X
        label.set_color('black')
        label.set_rotation(-45)
        label.set_fontsize(9)
    for label in ax.yaxis.get_ticklabels(): # Настройка оси Y
        label.set_fontsize(9)
    for label in ax.zaxis.get_ticklabels(): # Настройка оси Z
        label.set_fontsize(9)
    ax.view_init(elev = 30, azim = 45) # Проецирование
    fig.colorbar(surf, shrink = 0.5, aspect = 5) # Шкала цветов
    plt.show() # Отображение результата
    exit()    

def texInit():
    if texFromFile:
        fn = 'C:\\Users\\Максим\\Pictures\\1356816110_umilnye-zhivotnye-24.jpg'
        img = pyglet.image.load(fn)
        iWidth = img.width
        iHeight = img.height
        img = img.get_data('RGB', iWidth * 3)
    else:
        iWidth = iHeight = 64
        n = 3 * iWidth * iHeight
        img = np.zeros((3, iWidth, iHeight), dtype = 'uint8')
        for i in range(iHeight):
             for j in range(iWidth):
                img[:, i, j] = ((i - 1) & 16 ^ (j - 1) & 16) * 255
        img = img.reshape(n)
        img = (gl.GLubyte * n)(*img)
    p = gl.GL_TEXTURE_2D
    r = gl.GL_RGB
    gl.glTexParameterf(p, gl.GL_TEXTURE_WRAP_S, gl.GL_REPEAT)
    gl.glTexParameterf(p, gl.GL_TEXTURE_WRAP_T, gl.GL_REPEAT)
    gl.glTexParameterf(p, gl.GL_TEXTURE_MAG_FILTER, gl.GL_LINEAR)
    gl.glTexParameterf(p, gl.GL_TEXTURE_MIN_FILTER, gl.GL_LINEAR)
    gl.glTexEnvf(gl.GL_TEXTURE_ENV, gl.GL_TEXTURE_ENV_MODE, gl.GL_DECAL)
    gl.glTexImage2D(p, 0, r, iWidth, iHeight, 0, r, gl.GL_UNSIGNED_BYTE, img)
    if use_txtr:
        gl.glEnable(p)    
def c_float_Array(data): 
    return (gl.GLfloat * len(data))(*data)
lghtClr0 = [1, 0, 0, 0]
mtClr = c_float_Array([1, 1, 0, 0])
light_position = c_float_Array([-80, 20, 90, 0])
lghtClr = c_float_Array([1, 0, 0, 0])
    
width, height = int(20 * wx), int(20 * wy) 
window = Window(visible = True, width = width, height = height,
                resizable = True, caption = 'Половина однополосного гиперболоида')
gl.glClearColor(1, 1, 1, 1.0)
gl.glClear(gl.GL_COLOR_BUFFER_BIT|gl.GL_DEPTH_BUFFER_BIT)
gl.glPolygonMode(gl.GL_FRONT, gl.GL_FILL)
gl.glCullFace(gl.GL_BACK)
gl.glEnable(gl.GL_CULL_FACE)
if show_normals:
    gl.glEnable(gl.GL_DEPTH_TEST)
gl.glEnable(gl.GL_LIGHTING)
gl.glPointSize(3)
gl.glLineWidth(2)
texInit()
@window.event
def on_draw():
    global vrts, vrts_down, vrts_top, ca, cb, cc, nn
    window.clear()
    gl.glMatrixMode(gl.GL_PROJECTION)
    gl.glLoadIdentity()
    gl.glOrtho(-wx, wx, -wy, wy, -20, 20)
    gl.glRotatef(rot_x, 1, 0, 0) 
    gl.glRotatef(rot_y, 0, 1, 0) 
    gl.glRotatef(rot_z, 0, 0, 1)
    gl.glMaterialfv(gl.GL_FRONT, gl.GL_SPECULAR, mtClr)
    gl.glLightfv(gl.GL_LIGHT0, gl.GL_POSITION, light_position)
    gl.glLightfv(gl.GL_LIGHT0, gl.GL_SPECULAR, lghtClr)
    gl.glEnable(gl.GL_LIGHT0)
    #Нижняя крышка
    gl.glBegin(gl.GL_POLYGON)
    gl.glNormal3f(nrm_down[0],nrm_down[1],nrm_down[2])
    k = 0
    while (k<len(vrts_down)):
        v = vrts_down[k]
        tc = textr_down[k]
        if (fl == True):
            ca = random.random()
            cb = random.random()
            cc = random.random()
            gl.glColor3f(ca,cb,cc)
        else:
            gl.glColor3f(ca,cb,cc)
        gl.glTexCoord2f(tc[0],tc[1])
        gl.glVertex3f(v[0],v[1],v[2])
        k+=1
    gl.glEnd()
    #Верхняя крышка
    gl.glBegin(gl.GL_POLYGON)
    gl.glNormal3f(nrm_top[0],nrm_top[1],nrm_top[2])
    k = 0
    while (k<len(vrts_top)):
        v = vrts_top[k]
        tc = textr_top[k]
        if (fl == True):
            ca = random.random()
            cb = random.random()
            cc = random.random()
            gl.glColor3f(ca,cb,cc)
        else:
            gl.glColor3f(ca,cb,cc)
        gl.glTexCoord2f(tc[0],tc[1])
        gl.glVertex3f(v[0],v[1],v[2])
        k+=1
    gl.glEnd()    
    #Боковая сторона параболоида
    gl.glBegin(gl.GL_QUADS)
    k = 0
    while (k<len(vrts)):  
        v = vrts[k]
        v0 = v[0]; v1 = v[1]; v2 = v[2]; v3 = v[3]
        if (fl == True):
            ca = random.random()
            cb = random.random()
            cc = random.random()
            gl.glColor3f(ca,cb,cc)
        else:
            gl.glColor3f(ca,cb,cc)
        sn = nrms[k]
        tc = textr[k]
        gl.glNormal3f(sn[0],sn[1],sn[2])
        gl.glTexCoord2f(tc[0],tc[1])
        gl.glVertex3f(v0[0],v0[1],v0[2])
        #sn = nrms[k+1]
        #gl.glNormal3f(sn[0],sn[1],sn[2])
        gl.glTexCoord2f(tc[0]+0.1,tc[1])
        gl.glVertex3f(v1[0],v1[1],v1[2])
        #sn = nrms[k+10]
        #gl.glNormal3f(sn[0],sn[1],sn[2])
        gl.glTexCoord2f(tc[0]+0.1,tc[1]+0.1)
        gl.glVertex3f(v2[0],v2[1],v2[2])
        #sn = nrms[k+10-1]
        #gl.glNormal3f(sn[0],sn[1],sn[2])
        gl.glTexCoord2f(tc[0],tc[1]+0.1)
        gl.glVertex3f(v3[0],v3[1],v3[2])
        k+=1
    gl.glEnd()
    if show_normals:
        k = 0
        gl.glDisable(gl.GL_LIGHTING)
        gl.glColor3f(0,0,0)
        gl.glBegin(gl.GL_LINES)
        while (k<len(vrts)):
            v = vrts[k][0]
            gl.glVertex3f(v[0], v[1], v[2])
            sn = nrms[k]
            sx = 2 * sn[0]
            sy = 2 * sn[1]
            sz = 2 * sn[2]
            gl.glVertex3f(v[0] + sx, v[1] + sy, v[2] + sz)
            k+=1
        gl.glEnd()
        
        gl.glColor3f(1,1,0)
        gl.glBegin(gl.GL_LINES)
        gl.glVertex3f(0,0,10*np.sinh(-1))
        gl.glVertex3f(2*nrm_top[0],2*nrm_top[1],10*np.sinh(-1) + 2*nrm_top[2])
        gl.glEnd()
        
        gl.glColor3f(1,1,0)
        gl.glBegin(gl.GL_LINES)
        gl.glVertex3f(0,0,10*np.sinh(0))
        gl.glVertex3f(2*nrm_down[0],2*nrm_down[1],10*np.sinh(0) + 2*nrm_down[2])
        gl.glEnd()
        
@window.event
def on_key_press(symbol, modifiers):
    global rot_x, rot_y, rot_z, ca, cb, cc, fl
    if symbol == key._1:
        gl.glPolygonMode(gl.GL_FRONT, gl.GL_LINE)
    elif symbol == key._2:
        gl.glPolygonMode(gl.GL_FRONT, gl.GL_POINT)
    elif symbol == key._3:
        gl.glDisable(gl.GL_LIGHTING)
        fl = True
        gl.glShadeModel(gl.GL_FLAT)
    elif symbol == key._4:
        gl.glDisable(gl.GL_LIGHTING)
        fl = True
        gl.glShadeModel(gl.GL_SMOOTH)
    elif symbol == key._5:
        fl = False
        rot_x +=5  
    elif symbol == key._6:
        fl = False
        rot_y +=5  
    elif symbol == key._7:
        fl = False
        rot_z +=5  
    elif symbol == key._8:
        gl.glPolygonMode(gl.GL_FRONT, gl.GL_FILL)  
        gl.glEnable(gl.GL_LIGHTING)
        fl = False
        ca = 1
        cb = 0
        cc = 0
app.run()


# In[ ]:




